import streamlit as st
import pandas as pd
import os

st.set_page_config(
    page_title="Smart Traffic Signal Optimization",
    page_icon="🚦",
    layout="wide"
)

st.title("🚦 Smart Traffic Signal Optimization")
st.subheader("Using Reinforcement Learning")

st.markdown("""
An intelligent traffic signal management system comparing
Fixed-Time, Q-Learning and Deep Q-Network controllers,
with ambulance-priority support.
""")

st.divider()

# Load latest five-seed evaluation results
CSV_PATH = "results/metrics/controller_multi_seed_summary.csv"

if not os.path.exists(CSV_PATH):
    st.error("Five-seed evaluation results not found.")
    st.stop()

raw = pd.read_csv(CSV_PATH)

# Convert long-format data into dashboard-friendly columns
df = raw.pivot(
    index="Controller",
    columns="Metric",
    values=["Mean", "Std Dev"]
)

df.columns = [f"{metric}_{stat}" for stat, metric in df.columns]
df = df.reset_index()

# Overall performance
st.markdown("### 📊 Overall Performance")

best_wait = df.loc[df["average_waiting_time_Mean"].idxmin()]
best_queue = df.loc[df["average_queue_length_Mean"].idxmin()]
best_ambulance = df.loc[
    df["average_ambulance_waiting_time_Mean"].idxmin()
]

c1, c2, c3, c4 = st.columns(4)

c1.metric(
    "Best Vehicle Waiting Time",
    f"{best_wait['average_waiting_time_Mean']:.3f} sec"
)
c1.caption(best_wait["Controller"])

c2.metric(
    "Best Queue Length",
    f"{best_queue['average_queue_length_Mean']:.3f}"
)
c2.caption(best_queue["Controller"])

c3.metric(
    "Best Ambulance Waiting Time",
    f"{best_ambulance['average_ambulance_waiting_time_Mean']:.3f} sec"
)
c3.caption(best_ambulance["Controller"])

c4.metric(
    "Maximum Throughput",
    f"{df['completed_vehicles_Mean'].max():.1f}"
)
c4.caption("Average completed vehicles")

st.divider()

# Controller comparison
st.markdown("### 📈 Controller Performance Comparison")

tab1, tab2, tab3, tab4 = st.tabs([
    "Waiting Time",
    "Queue Length",
    "Throughput",
    "Ambulance Waiting"
])

with tab1:
    st.bar_chart(
        df.set_index("Controller")["average_waiting_time_Mean"]
    )

with tab2:
    st.bar_chart(
        df.set_index("Controller")["average_queue_length_Mean"]
    )

with tab3:
    st.bar_chart(
        df.set_index("Controller")["completed_vehicles_Mean"]
    )

with tab4:
    st.bar_chart(
        df.set_index("Controller")[
            "average_ambulance_waiting_time_Mean"
        ]
    )

st.divider()

# Detailed results
st.markdown("### 📋 Detailed Five-Seed Evaluation Results")

st.caption(
    "Values are reported as mean and standard deviation across five random seeds."
)

display_df = df[[
    "Controller",
    "average_waiting_time_Mean",
    "average_waiting_time_Std Dev",
    "average_queue_length_Mean",
    "average_queue_length_Std Dev",
    "completed_vehicles_Mean",
    "average_ambulance_waiting_time_Mean"
]].copy()

display_df.columns = [
    "Controller",
    "Mean Waiting Time (sec)",
    "Waiting Time Std Dev",
    "Mean Queue Length",
    "Queue Std Dev",
    "Completed Vehicles (Mean)",
    "Ambulance Waiting Time (sec)"
]

st.dataframe(
    display_df,
    width="stretch",
    hide_index=True
)

st.divider()

# Project information
st.markdown("### 🧠 Project Information")

col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    **Traffic Controllers**
    - Fixed-Time
    - Fixed-Time + Ambulance Priority
    - Q-Learning + Ambulance Priority
    - DQN + Ambulance Priority
    """)

with col2:
    st.markdown("""
    **Evaluation Metrics**
    - Average vehicle waiting time
    - Average queue length
    - Completed vehicles
    - Ambulance waiting time
    - Standard deviation across five seeds
    """)

st.caption(
    "Smart Traffic Signal Optimization | SUMO + Python + TraCI + Streamlit"
)
